package com.pspl.contact;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pspl.contact.models.EmployeeDetails;

public class ContactSharedPreference {

	private SharedPreferences sharedPreferences;
	private static ContactSharedPreference contactSharedPrefrence;
	private Editor editor;
	Context context;
	private static final String Anand = "Anand";
	private static final String CONTACT_LIST = "CONTACT_LIST";
	Gson gson;

	public static ContactSharedPreference getInstance(Context context) {
		if (contactSharedPrefrence == null) {
			contactSharedPrefrence = new ContactSharedPreference(context);
		}
		return contactSharedPrefrence;

	}

	@SuppressLint("CommitPrefEdits")
	private ContactSharedPreference(Context context) {
		gson = new Gson();
		this.context = context;
		this.sharedPreferences = context.getSharedPreferences(Anand,
				Context.MODE_PRIVATE);
		this.editor = sharedPreferences.edit();
	}

	public List<EmployeeDetails> getContactList() {
		List<EmployeeDetails> list = null;
		String listObject = context.getSharedPreferences(Anand,
				Context.MODE_PRIVATE).getString(CONTACT_LIST, null);
		if (listObject != null) {
			Type type = new TypeToken<List<EmployeeDetails>>() {
			}.getType();
			list = gson.fromJson(listObject, type);
		} else {
			list = new ArrayList<EmployeeDetails>();
		}
		return list;
	}

	public void setContactList(List<EmployeeDetails> list) {
		if (list != null && list.size() > 0) {
			String userObject = gson.toJson(list);
			editor.putString(CONTACT_LIST, userObject);
			editor.commit();
		}
	}

	public Editor getEditor() {
		return editor;

	}

	public void commitEditer() {
		editor.commit();
	}

	public void clearEditor() {
		editor.clear();
		editor.commit();
	}

	// ---------------------------------------------------------------------------

	public void setIsLogin(boolean isLogin) {
		editor.putBoolean("isLogin", isLogin);
		editor.commit();
	}

	public boolean getIsLogin() {
		return sharedPreferences.getBoolean("isLogin", false);
	}

}

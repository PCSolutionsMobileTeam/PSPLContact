/** Automatically generated file. DO NOT MODIFY */
package com.atermenji.android.iconictextview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
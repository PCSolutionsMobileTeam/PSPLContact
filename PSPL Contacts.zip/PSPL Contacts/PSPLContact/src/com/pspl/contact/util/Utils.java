package com.pspl.contact.util;

import java.util.Random;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;

import com.pspl.contact.R;

public class Utils {

	public static final String no_internet = "No internet connection!!";
	public static final String dissmiss = "Dismiss";
	Context context;

	public static int randomColor() {
		Random random = new Random();
		return Color.rgb(random.nextInt(255), random.nextInt(255),
				random.nextInt(255));
	}

	public Utils(Context context) {
		this.context = context;
	}

	public static boolean checkInternetConnection(Context context) {

		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo wifiNetwork = cm
				.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (wifiNetwork != null && wifiNetwork.isConnected()) {
			return true;
		}

		NetworkInfo mobileNetwork = cm
				.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		if (mobileNetwork != null && mobileNetwork.isConnected()) {
			return true;
		}

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (activeNetwork != null && activeNetwork.isConnected()) {
			return true;
		}
		return false;
	}

	public static void showAlertDialog(final Activity context, String message,
			final String btn_title) {
		final Dialog dialog = new Dialog(context);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog.setCancelable(false);
		dialog.setContentView(R.layout.dissmiss_dialog);
		TextView tv_dialogtitle = (TextView) dialog
				.findViewById(R.id.tv_dismissTitle);
		tv_dialogtitle.setText(message);
		TextView tv_dissmiss = (TextView) dialog.findViewById(R.id.tv_dissmiss);
		tv_dissmiss.setText(btn_title);
		tv_dissmiss.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}
}

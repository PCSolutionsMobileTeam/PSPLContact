package com.pspl.contact.interfaces;

import org.json.JSONObject;

public interface IDevAnandResponse {
	public void IDevJitinJson(JSONObject object, int position);
}

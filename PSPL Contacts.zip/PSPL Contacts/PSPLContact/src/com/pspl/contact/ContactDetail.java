package com.pspl.contact;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.atermenji.android.iconictextview.IconicFontDrawable;
import com.atermenji.android.iconictextview.icon.EntypoIcon;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.ObjectAnimator;
import com.pspl.contact.dataholder.ContactHolder;
import com.pspl.contact.models.EmployeeDetails;
import com.pspl.contact.util.Utils;
import com.pspl.contact.widgets.WrapContentHeightViewPager;

public class ContactDetail extends Activity implements View.OnTouchListener {
	TextView sendBtn;
	EditText etPhoneno;
	EditText txtMessage;
	Context context;
	ViewPager pager;
	WrapContentHeightViewPager adapter;
	LayoutInflater inflater;
	List<EmployeeDetails> list;
	RelativeLayout baseLayout;
	private int previousFingerPosition = 0;
	private int baseLayoutPosition = 0;
	private int defaultViewHeight;

	private boolean isClosing = false;
	private boolean isScrollingUp = false;
	private boolean isScrollingDown = false;
	ContactSharedPreference preference;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		preference = ContactSharedPreference.getInstance(ContactDetail.this);
		baseLayout = (RelativeLayout) findViewById(R.id.relative_swipe);
		baseLayout.setOnTouchListener(this);
		list = preference.getContactList();
		pager = (WrapContentHeightViewPager) findViewById(R.id.pager);
		pager.setAdapter(new CustomPagerAdapter(ContactDetail.this));
		pager.setCurrentItem(ContactHolder.getInstance().getItemPosition());
		// pager.setCurrentItem(preference.getContactList().get(location))
		pager.setClipToPadding(false);
		pager.setPageMargin(12);
	}

	class CustomPagerAdapter extends PagerAdapter {
		Context mContext;
		LayoutInflater mLayoutInflater;

		public CustomPagerAdapter(Context context) {
			mContext = context;
			mLayoutInflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == ((LinearLayout) object);
		}

		@Override
		public Object instantiateItem(ViewGroup container, final int position) {
			View itemView = mLayoutInflater.inflate(R.layout.seconds,
					container, false);
			final int color = Utils.randomColor();
			char x = list.get(position).getName().charAt(0);
			RelativeLayout background = (RelativeLayout) itemView
					.findViewById(R.id.background);
			background.setBackgroundColor(color);
			TextView tv_contact = (TextView) itemView
					.findViewById(R.id.tv_nametitle);
			tv_contact.setTextColor(color);
			tv_contact.setText(String.valueOf(x));

			TextView tv_personal_phone = (TextView) itemView
					.findViewById(R.id.tv_personal_phone);
			tv_personal_phone.setTextColor(color);

			TextView tv_user_office_phone = (TextView) itemView
					.findViewById(R.id.tv_user_office_phone);
			tv_user_office_phone.setTextColor(color);

			TextView tv_useremail = (TextView) itemView
					.findViewById(R.id.tv_useremail);
			tv_useremail.setTextColor(color);

			TextView tv_OfficialEmail = (TextView) itemView
					.findViewById(R.id.tv_OfficialEmail);
			tv_OfficialEmail.setTextColor(color);

			// View text_call = (View) itemView.findViewById(R.id.view_call);
			// IconicFontDrawable iconPhoneDrawable = new IconicFontDrawable(
			// mContext);
			// iconPhoneDrawable.setIcon(EntypoIcon.PHONE);
			// iconPhoneDrawable.setIconColor(color);
			// text_call.setBackground(iconPhoneDrawable);

			View text_message = (View) itemView.findViewById(R.id.view_message);
			IconicFontDrawable iconMessage = new IconicFontDrawable(mContext);
			iconMessage.setIcon(EntypoIcon.COMMENT);
			iconMessage.setIconColor(color);
			text_message.setBackground(iconMessage);

			View msg_official = (View) itemView
					.findViewById(R.id.view_message1);
			IconicFontDrawable iconMessage1 = new IconicFontDrawable(mContext);
			iconMessage1.setIcon(EntypoIcon.COMMENT);
			iconMessage1.setIconColor(color);
			msg_official.setBackground(iconMessage1);

			// View text_email = (View) itemView.findViewById(R.id.view_email);
			// IconicFontDrawable iconEmail = new IconicFontDrawable(mContext);
			// iconEmail.setIcon(EntypoIcon.MAIL);
			// iconEmail.setIconColor(color);
			// text_email.setBackground(iconEmail);

			TextView tv_name = (TextView) itemView.findViewById(R.id.tv_name);
			tv_name.setText(list.get(position).getName());

			TextView tv_designation = (TextView) itemView
					.findViewById(R.id.tv_designation);
			tv_designation.setText(list.get(position).getDesignation());

			TextView tv_dept = (TextView) itemView.findViewById(R.id.tv_dept);
			tv_dept.setText(list.get(position).getDepartment());

			TextView tv_reportingMgr = (TextView) itemView
					.findViewById(R.id.tv_reportingMgr);
			tv_reportingMgr.setText(list.get(position).getReportingManager()
					+ " (Manager)");

			// -------------------------------------------------------------------------------------
			TextView tv_personal_phone1 = (TextView) itemView
					.findViewById(R.id.tv_personal_phone1);

			if (list.get(position).getPersonalMobile() != null
					&& !list.get(position).getPersonalMobile().isEmpty()
					&& list.get(position).getPersonalMobile().equals("")) {
				tv_personal_phone1.setVisibility(View.VISIBLE);
				tv_personal_phone1.setText(" 📱 Not available");
			} else if (list.get(position).getPersonalMobile() != null
					&& !list.get(position).getPersonalMobile().isEmpty()) {
				tv_personal_phone1.setVisibility(View.VISIBLE);
				tv_personal_phone1.setText(list.get(position)
						.getPersonalMobile().trim());
			} else {
				// tv_personal_phone1.setVisibility(View.GONE);
				tv_personal_phone1.setText(" 📱 Not available");
			}
			// --------------------------------------------------------------------------------------
			TextView tv_office_phone2 = (TextView) itemView
					.findViewById(R.id.tv_office_phone2);

			if (list.get(position).getOfficialMobile() != null
					&& !list.get(position).getOfficialMobile().isEmpty()
					&& list.get(position).getOfficialMobile().equals("")) {
				tv_office_phone2.setVisibility(View.VISIBLE);
				tv_office_phone2.setText(" 📱 Not available");

			} else if (list.get(position).getOfficialMobile() != null
					&& !list.get(position).getOfficialMobile().isEmpty()) {
				tv_office_phone2.setVisibility(View.VISIBLE);
				tv_office_phone2.setText(list.get(position).getOfficialMobile()
						.trim());

			} else {
				tv_office_phone2.setText(" 📱 Not available");
			}
			// --------------------------------------------------------------------------------------
			TextView personalmail = (TextView) itemView
					.findViewById(R.id.useremail);
			if (list.get(position).getPersonalEmail() != null
					&& !list.get(position).getPersonalEmail().isEmpty()) {
				personalmail.setVisibility(View.VISIBLE);
				personalmail.setText(list.get(position).getPersonalEmail()
						.trim());
			} else {
				personalmail.setText("📧  Not available");
			}
			// ----------------------------------------------------------------------------------------------
			TextView useroffice_email2 = (TextView) itemView
					.findViewById(R.id.useroffice_email2);

			if (list.get(position).getOfficialEmail() != null
					&& !list.get(position).getOfficialEmail().isEmpty()) {
				useroffice_email2.setVisibility(View.VISIBLE);
				useroffice_email2.setText(list.get(position).getOfficialEmail()
						.trim());

			} else {
				useroffice_email2.setText("📧  Not available");

			}
			// -----------------------------------------------------------------------------------------------------
			// LinearLayout linear_call = (LinearLayout) itemView
			// .findViewById(R.id.linear_call);
			//
			// linear_call.setOnClickListener(new OnClickListener() {
			//
			// @Override
			// public void onClick(View v) {
			// if (list.get(position).getOfficialMobile().equals("")
			// && !list.get(position).getPersonalMobile()
			// .equals("")) {
			// call(list.get(position).getPersonalMobile().toString());
			// } else if (list.get(position).getPersonalMobile()
			// .equals("")
			// && !list.get(position).getOfficialMobile()
			// .equals("")) {
			// call(list.get(position).getOfficialMobile().toString());
			// } else if (!list.get(position).getPersonalMobile()
			// .equals("")
			// && !list.get(position).getOfficialMobile()
			// .equals("")) {
			// showDialog(color, "Call", list.get(position)
			// .getPersonalMobile().trim(), list.get(position)
			// .getOfficialMobile().trim());
			// } else {
			// Toast.makeText(ContactDetail.this,
			// "Contact number not available!",
			// Toast.LENGTH_SHORT).show();
			// }
			//
			// }
			// });

			tv_personal_phone1.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getPersonalMobile().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Contact number not available!",
								Toast.LENGTH_SHORT).show();
					} else {
						call(list.get(position).getPersonalMobile().toString());
					}
				}
			});

			tv_office_phone2.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getOfficialMobile().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Contact number not available!",
								Toast.LENGTH_SHORT).show();
					} else {
						call(list.get(position).getOfficialMobile().toString());
					}
				}
			});

			// ----------comment--------------------
			// LinearLayout linear_message = (LinearLayout) itemView
			// .findViewById(R.id.linear_message);
			// linear_message.setOnClickListener(new OnClickListener() {
			//
			// @Override
			// public void onClick(View v) {
			// if (list.get(position).getOfficialMobile().equals("")
			// && !list.get(position).getPersonalMobile()
			// .equals("")) {
			// sendSMSMessage(list.get(position).getPersonalMobile()
			// .toString());
			// } else if (list.get(position).getPersonalMobile()
			// .equals("")
			// && !list.get(position).getOfficialMobile()
			// .equals("")) {
			// sendSMSMessage(list.get(position).getOfficialMobile()
			// .toString());
			// } else if (!list.get(position).getPersonalMobile()
			// .equals("")
			// && !list.get(position).getOfficialMobile()
			// .equals("")) {
			// showDialog(color, "SendSMS", list.get(position)
			// .getPersonalMobile().trim(), list.get(position)
			// .getOfficialMobile().trim());
			// } else {
			// Toast.makeText(ContactDetail.this,
			// "Contact number not available!",
			// Toast.LENGTH_SHORT).show();
			// }
			//
			// if (list.get(position).getOffice() != null
			// && !list.get(position).getOffice().isEmpty()) {
			// showDialog(color, "Message", list.get(position)
			// .getPersonalMobile().trim(), list.get(position)
			// .getOffice().trim());
			// } else {
			// sendSMSMessage(list.get(position).getPersonalMobile()
			// .trim());
			// }
			// }
			// });

			text_message.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getPersonalMobile().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Contact number not available!",
								Toast.LENGTH_SHORT).show();
					} else {
						sendSMSMessage(list.get(position).getPersonalMobile()
								.toString());
					}

				}
			});

			msg_official.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getOfficialMobile().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Contact number not available!",
								Toast.LENGTH_SHORT).show();
					} else {
						sendSMSMessage(list.get(position).getOfficialMobile()
								.toString());
					}

				}
			});
			//
			// LinearLayout linear_email = (LinearLayout) itemView
			// .findViewById(R.id.linear_email);
			// linear_email.setOnClickListener(new OnClickListener() {
			//
			// @Override
			// public void onClick(View v) {
			// if (list.get(position).getOfficialEmail().equals("")
			// && !list.get(position).getPersonalEmail()
			// .equals("")) {
			// Email(list.get(position).getPersonalEmail().toString());
			// } else if (list.get(position).getPersonalEmail().equals("")
			// && !list.get(position).getOfficialEmail()
			// .equals("")) {
			// Email(list.get(position).getOfficialEmail().toString());
			// } else if (!list.get(position).getPersonalEmail()
			// .equals("")
			// && !list.get(position).getOfficialEmail()
			// .equals("")) {
			// showEmailDialog(color, list.get(position)
			// .getPersonalEmail().trim(), list.get(position)
			// .getOfficialEmail().trim());
			// } else {
			// Toast.makeText(ContactDetail.this,
			// "Email not available!", Toast.LENGTH_SHORT)
			// .show();
			// }
			// // Email(list.get(position).getPersonalEmail().trim());
			// }
			// });

			personalmail.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getPersonalEmail().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Email not available!", Toast.LENGTH_SHORT)
								.show();
					} else {
						Email(list.get(position).getPersonalEmail().toString());
					}
				}
			});

			useroffice_email2.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (list.get(position).getOfficialEmail().equals("")) {
						Toast.makeText(ContactDetail.this,
								"Email not available!", Toast.LENGTH_SHORT)
								.show();
					} else {
						Email(list.get(position).getOfficialEmail().toString());
					}

				}
			});

			container.addView(itemView);
			return itemView;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((LinearLayout) object);
		}
	}

	@SuppressLint("ClickableViewAccessibility")
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		System.out.println("I am in Touch Listener");
		final int Y = (int) event.getRawY();
		switch (event.getAction() & MotionEvent.ACTION_MASK) {

		case MotionEvent.ACTION_DOWN:
			defaultViewHeight = baseLayout.getHeight();
			previousFingerPosition = Y;
			baseLayoutPosition = (int) baseLayout.getY();
			break;

		case MotionEvent.ACTION_UP:
			if (isScrollingUp) {
				baseLayout.setY(0);
				isScrollingUp = false;
			}
			if (isScrollingDown) {
				baseLayout.setY(0);
				baseLayout.getLayoutParams().height = defaultViewHeight;
				baseLayout.requestLayout();
				isScrollingDown = false;
			}
			break;
		case MotionEvent.ACTION_MOVE:
			if (!isClosing) {
				int currentYPosition = (int) baseLayout.getY();
				if (previousFingerPosition > Y) {
					if (!isScrollingUp) {
						isScrollingUp = true;
					}
					if (baseLayout.getHeight() < defaultViewHeight) {
						baseLayout.getLayoutParams().height = baseLayout
								.getHeight() - (Y - previousFingerPosition);
						baseLayout.requestLayout();
					} else {
						if ((baseLayoutPosition - currentYPosition) > defaultViewHeight / 4) {
							closeUpAndDismissDialog(currentYPosition);
							return true;
						}

					}
					baseLayout.setY(baseLayout.getY()
							+ (Y - previousFingerPosition));

				} else {

					if (!isScrollingDown) {
						isScrollingDown = true;
					}

					if (Math.abs(baseLayoutPosition - currentYPosition) > defaultViewHeight / 2) {
						closeDownAndDismissDialog(currentYPosition);
						return true;
					}

					baseLayout.setY(baseLayout.getY()
							+ (Y - previousFingerPosition));
					baseLayout.getLayoutParams().height = baseLayout
							.getHeight() - (Y - previousFingerPosition);
					baseLayout.requestLayout();
				}

				previousFingerPosition = Y;
			}
			break;
		}
		return true;
	}

	public void closeUpAndDismissDialog(int currentPosition) {
		isClosing = true;
		ObjectAnimator positionAnimator = ObjectAnimator.ofFloat(baseLayout,
				"y", currentPosition, -baseLayout.getHeight());
		positionAnimator.setDuration(300);
		positionAnimator.addListener(new Animator.AnimatorListener() {

			@Override
			public void onAnimationEnd(Animator animator) {
				finish();
			}

			@Override
			public void onAnimationCancel(Animator arg0) {

			}

			@Override
			public void onAnimationRepeat(Animator arg0) {

			}

			@Override
			public void onAnimationStart(Animator arg0) {

			}

		});
		positionAnimator.start();
	}

	public void closeDownAndDismissDialog(int currentPosition) {
		isClosing = true;
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int screenHeight = size.y;
		ObjectAnimator positionAnimator = ObjectAnimator.ofFloat(baseLayout,
				"y", currentPosition, screenHeight + baseLayout.getHeight());
		positionAnimator.setDuration(300);
		positionAnimator.addListener(new Animator.AnimatorListener() {

			@Override
			public void onAnimationEnd(Animator animator) {
				finish();
			}

			@Override
			public void onAnimationCancel(Animator arg0) {

			}

			@Override
			public void onAnimationRepeat(Animator arg0) {

			}

			@Override
			public void onAnimationStart(Animator arg0) {

			}
		});
		positionAnimator.start();
	}

	private void sendSMSMessage(String mobileNumber) {

		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.putExtra("sms_body", "");
		intent.setType("vnd.android-dir/mms-sms");
		intent.setData(Uri.parse("sms:" + mobileNumber));
		startActivity(intent);
	}

	private void call(String mobileNumber) {
		Intent callIntent = new Intent(Intent.ACTION_CALL);
		callIntent.setData(Uri.parse("tel:" + mobileNumber));
		startActivity(callIntent);

	}

	private void Email(String email) {
		Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
				"mailto", email, null));
		emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
		startActivity(Intent.createChooser(emailIntent, "Send email..."));
	}

	public void showEmailDialog(int color, final String email1,
			final String email2) {
		final Dialog dialog1 = new Dialog(ContactDetail.this);
		dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog1.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog1.setContentView(R.layout.dialog_layout);
		TextView tv_dialogtitle = (TextView) dialog1
				.findViewById(R.id.tv_dialogtitle);
		tv_dialogtitle.setText("Email");
		tv_dialogtitle.setBackgroundColor(color);

		TextView tv_number1 = (TextView) dialog1.findViewById(R.id.tv_number1);
		tv_number1.setText(email1);
		tv_number1.setTextColor(color);
		tv_number1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Email(email1);
			}
		});

		TextView tv_number2 = (TextView) dialog1.findViewById(R.id.tv_number2);
		tv_number2.setText(email2);
		tv_number2.setTextColor(color);
		tv_number2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Email(email2);
			}
		});
		dialog1.show();

	}

	public void showDialog(int color, final String title, final String number1,
			final String number2) {
		final Dialog dialog1 = new Dialog(ContactDetail.this);
		dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog1.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.graphics.Color.TRANSPARENT));
		dialog1.setContentView(R.layout.dialog_layout);
		TextView tv_dialogtitle = (TextView) dialog1
				.findViewById(R.id.tv_dialogtitle);
		tv_dialogtitle.setText(title);
		tv_dialogtitle.setBackgroundColor(color);

		TextView tv_number1 = (TextView) dialog1.findViewById(R.id.tv_number1);
		tv_number1.setText(number1);
		tv_number1.setTextColor(color);
		tv_number1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (title.equals("Call")) {
					call(number1);
					/*
					 * } else if(title.equals("Call")){ call(number2);
					 */
				} else {
					sendSMSMessage(number1);
				}
			}
		});

		TextView tv_number2 = (TextView) dialog1.findViewById(R.id.tv_number2);
		tv_number2.setText(number2);
		tv_number2.setTextColor(color);
		tv_number2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (title.equals("Call")) {
					call(number2);
				} else {
					sendSMSMessage(number2);
				}
			}
		});
		dialog1.show();
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		ContactDetail.this.finish();
		overridePendingTransition(0, R.anim.slide_out_to_bottom);
	}

}

package com.pspl.contact.dataholder;


public class ContactHolder {
	private static ContactHolder instance = null;

	private ContactHolder() {
	}

	public static ContactHolder getInstance() {
		if (instance == null)
			instance = new ContactHolder();
		return instance;
	}
	/*private ArrayList<String> employeName = new ArrayList<String>();
	
	public ArrayList<String> getEmployeName() {
		return employeName;
	}

	public void setEmployeName(String employeName11) {
		employeName.add(employeName11);
	}*/

	private int ItemPosition = 0;

	public int getItemPosition() {
		return ItemPosition;
	}

	public void setItemPosition(int itemPosition) {
		ItemPosition = itemPosition;
	}
}

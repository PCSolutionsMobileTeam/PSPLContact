package com.pspl.contact.interfaces;

import org.json.JSONObject;

public interface IVolleyJSONReponse {

	public void ResponseOk(JSONObject jsonObject);

	public void ErrorBlock();

}

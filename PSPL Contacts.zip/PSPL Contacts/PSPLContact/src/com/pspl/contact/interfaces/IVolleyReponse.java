package com.pspl.contact.interfaces;

import org.json.JSONArray;

public interface IVolleyReponse {
	
	public void ResponseOk(JSONArray jsonArray);

	public void ErrorBlock();

}

package com.pspl.contact.interfaces;


public interface IDevAnandStringResponse {
	public void IDevAnandJson(String object, int position);
}

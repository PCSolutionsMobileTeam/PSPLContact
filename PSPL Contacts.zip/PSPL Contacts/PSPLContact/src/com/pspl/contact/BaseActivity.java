package com.pspl.contact;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.pspl.contact.interfaces.IDevAnandStringResponse;
import com.pspl.contact.interfaces.IVolleyJSONReponse;
import com.pspl.contact.interfaces.IVolleyReponse;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

public class BaseActivity extends Activity {
	Context context;
	private static final int socketTimeout = 30000;
	private static final int maxTries = 4;
	ProgressDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	public void getVolleyTask(Context context,
			final IVolleyReponse responseContext, String URL) {
		RequestQueue request = Volley.newRequestQueue(context);
		StringRequest strReq = new StringRequest(Request.Method.GET, URL,
				new Response.Listener<String>() {

					@Override
					public void onResponse(String response) {
						try {
							if (response != null) {
								JSONArray _array = new JSONArray(response);
								responseContext.ResponseOk(_array);
							} else {
								responseContext.ResponseOk(null);
							}
						} catch (Exception e) {
							e.printStackTrace();
							responseContext.ResponseOk(null);
						}
					}
				}, new Response.ErrorListener() {

					@Override
					public void onErrorResponse(VolleyError error) {
						responseContext.ErrorBlock();
					}
				});
		strReq.setRetryPolicy(new DefaultRetryPolicy(socketTimeout, maxTries,
				DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
		request.add(strReq);
	}

	public void getVolleyPostTask(Context context,
			final IVolleyJSONReponse jsonResponseContext, String URL,
			JSONObject obj) {
		RequestQueue request = Volley.newRequestQueue(context);
		JsonObjectRequest myRequest = new JsonObjectRequest(
				Request.Method.POST, URL, obj,
				new Response.Listener<JSONObject>() {
					@Override
					public void onResponse(JSONObject response) {
						jsonResponseContext.ResponseOk(response);
					}
				}, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error) {
						jsonResponseContext.ErrorBlock();
					}
				}) {

			@Override
			public Map<String, String> getHeaders() throws AuthFailureError {
				HashMap<String, String> headers = new HashMap<String, String>();
				headers.put("Content-Type", "application/json; charset=utf-8");
				return headers;
			}
		};
		myRequest.setRetryPolicy(new DefaultRetryPolicy(socketTimeout,
				maxTries, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
		request.add(myRequest);
	}

	/*********** Json Response **********/

	public void DevAnandRequest(IDevAnandStringResponse context, String URL,
			JSONObject obj, int position) {
		DevAnandTask task = new DevAnandTask(context, URL, obj, position);
		task.execute();
	}

	private class DevAnandTask extends AsyncTask<Void, Void, String> {
		String URL;
		JSONObject obj;
		IDevAnandStringResponse context;
		int position;

		public DevAnandTask(IDevAnandStringResponse context, String URL,
				JSONObject obj, int position) {
			this.context = context;
			this.URL = URL;
			this.obj = obj;
			this.position = position;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			dialog = ProgressDialog.show(BaseActivity.this, "",
					"Please Wait...");
		}

		@Override
		protected String doInBackground(Void... params) {
			String object = null;
			try {
				object = getJSON(URL, obj);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return object;
		}

		@Override
		protected void onPostExecute(String result) {
			context.IDevAnandJson(result, position);
			dialog.dismiss();
		}

		private String getJSON(String URL, JSONObject obj) throws JSONException {
			String responseString = null;
			try {
				HttpPost httppost = new HttpPost(URL);
				StringEntity se = new StringEntity(obj.toString(), HTTP.UTF_8);
				httppost.setHeader("Content-Type", "application/json");

				httppost.setEntity(se);

				HttpParams httpParams = new BasicHttpParams();
				HttpConnectionParams.setConnectionTimeout(httpParams, 30000);
				HttpClient httpclient = new DefaultHttpClient(httpParams);
				HttpResponse httpResponse = httpclient.execute(httppost);

				StatusLine statusLine = httpResponse.getStatusLine();
				int statusCode = statusLine.getStatusCode();
				System.out.println("status code is" + statusCode);
				HttpEntity entity = httpResponse.getEntity();
				responseString = EntityUtils.toString(entity, "UTF-8");
				System.out.println("response string" + responseString);
				Log.i("RESPONSE XML ------> ", "-----> " + responseString);
				return responseString;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return responseString;
		}
	}
}
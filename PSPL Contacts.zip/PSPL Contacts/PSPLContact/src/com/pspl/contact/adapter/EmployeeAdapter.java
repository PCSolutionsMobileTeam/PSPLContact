package com.pspl.contact.adapter;

import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.pspl.contact.R;
import com.pspl.contact.models.EmployeeDetails;
import com.pspl.contact.widgets.CircularImageView;

@SuppressLint("InflateParams")
public class EmployeeAdapter extends BaseAdapter {
	List<EmployeeDetails> list;
	Context context;
	LayoutInflater inflater;

	public EmployeeAdapter(Context context, List<EmployeeDetails> list) {
		this.list = list;
		this.context = context;
		inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			convertView = inflater.inflate(R.layout.emp_item, null);

		}
		CircularImageView imageView=(CircularImageView) convertView.findViewById(R.id.profile_image);
		imageView.setImageResource(R.drawable.profile_image);
		EmployeeDetails emp = list.get(position);
		TextView tv_name = (TextView) convertView.findViewById(R.id.emp_Name);
		tv_name.setText(emp.getName());
		TextView tv_designation = (TextView) convertView
				.findViewById(R.id.emp_designation);
		tv_designation.setText(emp.getDesignation());
		TextView emp_number = (TextView) convertView
				.findViewById(R.id.emp_number);
		emp_number.setText(emp.getPersonalMobile());
		YoYo.with(Techniques.Pulse).duration(650).playOn(convertView);
		return convertView;

	}
}

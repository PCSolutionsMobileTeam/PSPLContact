package com.pspl.contact;

import java.util.Comparator;

public class TestComparator implements Comparator<Object> {

	public int compare(Object obj1, Object obj2) {
		Contact p1 = (Contact) obj1;
		Contact p2 = (Contact) obj2;

		String p1name = p1.getFirstname();
		String p2name = p2.getFirstname();

		return p1name.compareTo(p2name);
	}
/*
	public static void main(String[] args) {
		List<Employee> elist = new ArrayList<Employee>();

		elist.add(new Employee("Arvind", 25));
		elist.add(new Employee("Arvind", 15));
		elist.add(new Employee("Arvind", 20));

		Collections.sort(elist, new TestComparator());

		for (Employee e : elist) {
			System.out.println(e.firstname + " " + e.getAge());
		}
	}
*/
}

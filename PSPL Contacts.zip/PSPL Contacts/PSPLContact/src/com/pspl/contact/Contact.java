package com.pspl.contact;

class Contact {

	String firstname;

	public Contact(String firstname) {
		super();
		this.firstname = firstname;
	}

	public String getFirstname() {
		return firstname;
	}
}

package com.pspl.contact.util;

import java.util.HashMap;
import java.util.Map.Entry;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class HttpSoapClient {

	public static SoapObject soapRequest(String NAMESPACE, String METHOD_NAME,
			String URL, String SOAP_ACTION, HashMap<String, String> map) {
		SoapObject result = null;
		try {

			SoapSerializationEnvelope env = new SoapSerializationEnvelope(
					SoapEnvelope.VER11);

			env.dotNet = true;
			env.xsd = SoapSerializationEnvelope.XSD;
			env.xsi = SoapSerializationEnvelope.XSI;

			SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
			for (Entry<String, String> entry : map.entrySet()) {
				System.out.println(entry.getKey() + "/" + entry.getValue());
				request.addProperty(entry.getKey(), entry.getValue());

			}
			env.setOutputSoapObject(request);

			HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

			androidHttpTransport.call(SOAP_ACTION, env);
			result = (SoapObject) env.bodyIn;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

}

package com.pspl.contact.util;

public class ContactURL {
	/*public static final String LOGIN_URL = "http://221.135.139.134:8089/Service1.svc/spin/LoginAppUser";
	public static final String CONTACTS_URL = "http://221.135.139.134:8089/Service1.svc/spin/AppShowDetails";*/
	
	//----New---URL-------------------------------------------------------------------------------------
	public static final String LOGIN_URL = "http://erm.e-pspl.com:9047/Service1.svc/spin/LoginAppUser";
	public static final String CONTACTS_URL = "http://erm.e-pspl.com:9047/Service1.svc/spin/AppShowDetails";
}

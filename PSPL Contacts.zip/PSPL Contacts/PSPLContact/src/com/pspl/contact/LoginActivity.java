package com.pspl.contact;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.pspl.contact.interfaces.IVolleyJSONReponse;
import com.pspl.contact.util.ContactURL;

public class LoginActivity extends BaseActivity implements IVolleyJSONReponse {
	EditText et_id, et_password;
	Button login_button;
	HashMap<String, String> map;
	SharedPreferences.Editor editor;
	String LOGIN_ID = "loginid";
	String USERNAME = "username";
	String USER = "User";
	ContactSharedPreference prefernces;
	ProgressDialog progress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		prefernces=ContactSharedPreference.getInstance(getApplicationContext());
		if(prefernces.getIsLogin()){
			goToNext();
			
		}/*else{
			Intent goToLoginActity=new Intent(LoginActivity.this,LoginActivity.class);
			startActivity(goToLoginActity);
		}*/
		/*prefernces = getSharedPreferences(USER, Context.MODE_PRIVATE);
		String loginId = prefernces.getString(LOGIN_ID, "0");
		String username = prefernces.getString(USERNAME, "0");
		if (loginId.equals("0") && username.equals("0")) {

		} else {
			goToNext();
		}*/
		setContentView(R.layout.login_activity);
		editor = getSharedPreferences(USER, Context.MODE_PRIVATE).edit();
		et_id = (EditText) findViewById(R.id.et_id);
		et_password = (EditText) findViewById(R.id.et_password);
		login_button = (Button) findViewById(R.id.login_button);

		login_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (et_id.getText().toString().trim().isEmpty()) {
					showToast("Please enter login Id");
					return;

				} else if (et_password.getText().toString().trim().isEmpty()) {
					showToast("Please enter Password");
					return;

				} else {
					// new LoginTask().execute();
					try {
						progress = ProgressDialog.show(LoginActivity.this, "",
								"Please Wait..", true);
						JSONObject obj = new JSONObject();
						obj.put("LoginAppUserId", et_id.getText().toString()
								.trim());
						obj.put("LoginAppPassword", et_password.getText()
								.toString().trim());
						getVolleyPostTask(LoginActivity.this,
								LoginActivity.this, ContactURL.LOGIN_URL, obj);
					} catch (Exception e) {
						// TODO: handle exception
					}

				}
			}
		});
	}
	public void showToast(String message) {
		Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
	}

	public void goToNext() {
		Intent login = new Intent(LoginActivity.this, HomeActivity.class);
		startActivity(login);
		finish();
	}
	@Override
	public void ResponseOk(JSONObject jsonObject) {
		System.out.println("Login Responce Is" + jsonObject);
		try {
			if (jsonObject != null
					&& jsonObject.getString("LoginAPPMessage").equals(
							"Login Successfully")) {
				showToast("Login Successfully");
				Intent login = new Intent(LoginActivity.this,
						HomeActivity.class);
				prefernces.setIsLogin(true);
				startActivity(login);
				finish();
				progress.dismiss();
				// prefernces.
			
			} else if (jsonObject != null
					&& jsonObject.getString("LoginAPPMessage").equals(
							"Login Failed")) {
				showToast("Login Failed");
				progress.dismiss();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Override
	public void ErrorBlock() {
		System.out.println("I Am In Error");
	}
}
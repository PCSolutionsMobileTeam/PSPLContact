package com.pspl.contact;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.pspl.contact.adapter.EmployeeAdapter;
import com.pspl.contact.dataholder.ContactHolder;
import com.pspl.contact.interfaces.IVolleyReponse;
import com.pspl.contact.models.EmployeeDetails;
import com.pspl.contact.util.ContactURL;
import com.pspl.contact.util.Utils;
import com.pspl.contact.widgets.SearchEditText;
import com.pspl.parser.JSONParser;

public class HomeActivity extends BaseActivity implements IVolleyReponse,
		OnRefreshListener {

	private ListView listView;
	TextView EmpName;
	TextView Empdesignation;
	TextView Empmobile;;
	TextView Empofficemobile;
	TextView email;
	SearchEditText edittext_search;
	RelativeLayout search_layout;
	TextView action_bar_title;
	RelativeLayout title_bar_left_menu;
	ProgressDialog progress;
	ArrayList<EmployeeDetails> list;
	ArrayList<String> arraylist;
	Contact comparator;
	ImageView app_icon;
	JSONParser parser;
	SwipeRefreshLayout swipe_container;
	ContactSharedPreference preference;
	boolean isRefreshing = false;
	boolean upper = false;
	boolean lower = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listactivity);
		preference = ContactSharedPreference.getInstance(HomeActivity.this);
		parser = new JSONParser();
		swipe_container = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
		listView = (ListView) findViewById(R.id.list_emp);
		title_bar_left_menu = (RelativeLayout) findViewById(R.id.title_bar_left_menu);
		edittext_search = (SearchEditText) findViewById(R.id.edittext_search);
		search_layout = (RelativeLayout) findViewById(R.id.search_layout);
		action_bar_title = (TextView) findViewById(R.id.action_bar_title);
		search_layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				search_layout.setVisibility(View.GONE);
				action_bar_title.setVisibility(View.GONE);
				edittext_search.setVisibility(View.VISIBLE);
				edittext_search.requestFocus();
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
			}
		});
		edittext_search.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				String find = s.toString();
				List<EmployeeDetails> temp = setsearchlist(find);
				listView.setAdapter(new EmployeeAdapter(
						getApplicationContext(), temp));
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		title_bar_left_menu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				onBackPressed();

			}
		});
		if (preference.getContactList().size() == 0) {
			callWebService(true);
		} else {
			listView.setAdapter(new EmployeeAdapter(HomeActivity.this,
					preference.getContactList()));
		}
		swipe_container.setOnRefreshListener(this);
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				hideKeyboard();

				if (!isRefreshing) {
					EmployeeDetails contact = (EmployeeDetails) parent
							.getItemAtPosition(position);
					int pos = checkPositon(contact.getId());
					// int pos = checkPositon(contact.getPersonalMobile());
					ContactHolder.getInstance().setItemPosition(pos);
					goToNext();
				} else {
					Toast.makeText(HomeActivity.this,
							"Please wait\nContatct is updating...",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		listView.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				boolean enable = false;
				if (listView != null && listView.getChildCount() > 0) {
					boolean firstItemVisible = listView
							.getFirstVisiblePosition() == 0;
					boolean topOfFirstItemVisible = listView.getChildAt(0)
							.getTop() == 0;
					enable = firstItemVisible && topOfFirstItemVisible;
				}
				swipe_container.setEnabled(enable);
			}
		});
	}

	public void callWebService(boolean isShowProgress) {
		try {
			if (isShowProgress) {
				progress = ProgressDialog.show(HomeActivity.this, "",
						"Please Wait..", true);
			}
			getVolleyTask(HomeActivity.this, HomeActivity.this,
					ContactURL.CONTACTS_URL);
		} catch (Exception e) {
		}
	}

	@Override
	public void ResponseOk(JSONArray jsonArray) {
		try {
			isRefreshing = false;
			if (swipe_container.isRefreshing()) {
				swipe_container.setRefreshing(false);
			}
			if (progress != null && progress.isShowing()) {
				progress.dismiss();
			}
			if (jsonArray != null && jsonArray.length() > 0) {
				parser.parseContactsDetsils(preference, jsonArray);
				listView.setAdapter(new EmployeeAdapter(HomeActivity.this,
						preference.getContactList()));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ErrorBlock() {
		try {
			isRefreshing = false;
			if (swipe_container.isRefreshing()) {
				swipe_container.setRefreshing(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ------------------------------------------------------------------------------
	public int checkPositon(int id) {
		int position = 0;
		List<EmployeeDetails> list = preference.getContactList();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getId() == id) {
				position = i;
				break;
			}
		}
		return position;
	}

	public void goToNext() {
		Intent second = new Intent(HomeActivity.this, ContactDetail.class);
		startActivity(second);
		overridePendingTransition(R.anim.slide_in_from_bottom,
				android.R.anim.fade_out);
	}

	@SuppressLint("DefaultLocale")
	public List<EmployeeDetails> setsearchlist(String find) {
		List<EmployeeDetails> list = new ArrayList<EmployeeDetails>();
		List<EmployeeDetails> tempList = preference.getContactList();
		list.clear();
		for (int i = 0; i < tempList.size(); i++) {
			if (tempList.get(i).getName().trim().toLowerCase()
					.contains(find.toLowerCase())
					|| tempList.get(i).getPersonalMobile().trim()
							.contains(find)
					|| tempList.get(i).getOfficialMobile().trim()
							.contains(find)) {
				list.add(tempList.get(i));
			}
		}
		return list;
	}

	@Override
	public void onBackPressed() {
		if (!search_layout.isShown()) {
			search_layout.setVisibility(View.VISIBLE);
			action_bar_title.setVisibility(View.VISIBLE);
			edittext_search.setVisibility(View.GONE);
			List<EmployeeDetails> temp = setsearchlist("");
			listView.setAdapter(new EmployeeAdapter(getApplicationContext(),
					temp));
			hideKeyboard();
		} else {
			super.onBackPressed();
		}
	}

	@Override
	public void onRefresh() {
		if (Utils.checkInternetConnection(HomeActivity.this)) {
			if (!isRefreshing) {
				callWebService(false);
				isRefreshing = true;
			}
		} else {
			Utils.showAlertDialog(HomeActivity.this, Utils.no_internet,
					Utils.dissmiss);
			swipe_container.setRefreshing(false);
		}
	}

	private void hideKeyboard() {
		View view = this.getCurrentFocus();
		if (view != null) {
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
		}
	}
}

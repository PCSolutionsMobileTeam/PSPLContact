package com.pspl.parser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.pspl.contact.ContactSharedPreference;
import com.pspl.contact.models.EmployeeDetails;

public class JSONParser {
	public void parseContactsDetsils(ContactSharedPreference preference,
			JSONArray _array) {
		try {
			List<EmployeeDetails> list = new ArrayList<EmployeeDetails>();
			for (int i = 0; i < _array.length(); i++) {
				JSONObject object = _array.getJSONObject(i);
				EmployeeDetails model = new EmployeeDetails();
				model.setId(i);
				model.setName(object.getString("firstname") + " "
						+ object.getString("lastName"));

				System.out.println(" Anand " + model.getName());

				if (object.getString("contactNumber").equals("")) {
					model.setPersonalMobile("");
				} else {
					model.setPersonalMobile("" + "+" + "91"
							+ object.getString("contactNumber"));
				}

				if (object.getString("email").equals("")) {
					model.setPersonalEmail("");
				} else {
					model.setPersonalEmail(object.getString("email"));
				}

				if (object.getString("OfficialNumber").equals("")) {
					model.setOfficialMobile("");
				} else {
					model.setOfficialMobile("" + "+" + "91"
							+ object.getString("OfficialNumber"));
				}

				if (object.getString("OfficialEmail").equals("")) {
					model.setOfficialEmail("");
				} else {
					model.setOfficialEmail(object.getString("OfficialEmail"));
				}

				model.setDesignation(object.getString("designation"));
				model.setDepartment(object.getString("department"));
				model.setReportingManager(object.getString("reportingManager"));

				list.add(model);
			}
			Collections.sort(list, new MyEMPComp());
			preference.setContactList(list);
		} catch (Exception e) {
		}
	}

	class MyEMPComp implements Comparator<EmployeeDetails> {

		@Override
		public int compare(EmployeeDetails e1, EmployeeDetails e2) {
			return e1.getName().compareToIgnoreCase(e2.getName());
		}
	}

}
